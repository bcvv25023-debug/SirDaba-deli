package com.sirdaba.sirdaba_delivery.api;

import android.content.Context;
import com.sirdaba.sirdaba_delivery.utils.TokenManager;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.*;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    public static final String BASE_URL = "https://sirdaba.delivery/";
    public static final String AJAX_URL = BASE_URL + "wp-admin/admin-ajax.php";
    public static final String REST_URL = BASE_URL + "wp-json/";
    public static final String USER_AGENT = "SirDaba-App-Android-Agent/2.0";

    private static Retrofit retrofit;
    private static OkHttpClient okHttpClient;

    public static OkHttpClient getOkHttpClient(Context context) {
        if (okHttpClient == null) {
            CookieJar cookieJar = new PersistentCookieJar(context);
            okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .cookieJar(cookieJar)
                .addInterceptor(chain -> {
                    Request original = chain.request();
                    Request.Builder builder = original.newBuilder()
                        .header("User-Agent", USER_AGENT)
                        .header("Accept", "application/json")
                        .header("X-Requested-With", "XMLHttpRequest");

                    // Add JWT Bearer token if available
                    String token = TokenManager.getJwtToken(context);
                    if (token != null && !token.isEmpty()) {
                        builder.header("Authorization", "Bearer " + token);
                    }

                    return chain.proceed(builder.build());
                })
                .build();
        }
        return okHttpClient;
    }

    public static Retrofit getRetrofit(Context context) {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                .baseUrl(REST_URL)
                .client(getOkHttpClient(context))
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        }
        return retrofit;
    }

    public static ApiService getService(Context context) {
        return getRetrofit(context).create(ApiService.class);
    }

    // Reset clients when token changes
    public static void reset() {
        retrofit = null;
        okHttpClient = null;
    }
}
