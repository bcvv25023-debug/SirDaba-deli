package com.sirdaba.sirdaba_delivery.api;

import android.content.Context;
import android.util.Log;
import com.sirdaba.sirdaba_delivery.models.*;
import com.sirdaba.sirdaba_delivery.utils.TokenManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SirDabaRepository {

    private static final String TAG = "SirDabaRepo";
    private final Context ctx;
    private final ApiService api;

    public interface Callback<T> {
        void onSuccess(T data);
        void onError(String message);
    }

    public SirDabaRepository(Context context) {
        this.ctx = context.getApplicationContext();
        this.api = ApiClient.getService(ctx);
    }

    // ── Login ─────────────────────────────────────────────────────
    public void login(String email, String password, Callback<LoginResponse> cb) {
        // Step 1: Get JWT token
        api.getJwtToken(email, password).enqueue(new retrofit2.Callback<JwtResponse>() {
            @Override
            public void onResponse(Call<JwtResponse> call, Response<JwtResponse> resp) {
                if (resp.isSuccessful() && resp.body() != null && resp.body().success) {
                    String jwt = resp.body().data.token;
                    TokenManager.saveJwtToken(ctx, jwt);
                    ApiClient.reset(); // Rebuild with new token

                    // Step 2: Set cookie on server
                    ApiClient.getService(ctx).setAppTokenCookie(jwt).enqueue(new retrofit2.Callback<BaseResponse>() {
                        @Override
                        public void onResponse(Call<BaseResponse> c, Response<BaseResponse> r) {
                            // Step 3: Get user profile
                            fetchCurrentUser(cb);
                        }
                        @Override
                        public void onFailure(Call<BaseResponse> c, Throwable t) {
                            fetchCurrentUser(cb); // Continue even if cookie fails
                        }
                    });
                } else {
                    // JWT failed — try AJAX login fallback
                    ajaxLogin(email, password, cb);
                }
            }
            @Override
            public void onFailure(Call<JwtResponse> call, Throwable t) {
                ajaxLogin(email, password, cb);
            }
        });
    }

    private void ajaxLogin(String email, String password, Callback<LoginResponse> cb) {
        api.distLogin("sirdaba_dist_login", email, password, "")
            .enqueue(new retrofit2.Callback<LoginResponse>() {
                @Override
                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> resp) {
                    if (resp.isSuccessful() && resp.body() != null && resp.body().success) {
                        LoginResponse body = resp.body();
                        if (body.nonce != null) TokenManager.saveNonce(ctx, body.nonce);
                        if (body.jwtToken != null) {
                            TokenManager.saveJwtToken(ctx, body.jwtToken);
                            ApiClient.reset();
                        }
                        if (body.user != null) {
                            TokenManager.saveUser(ctx,
                                body.user.id, body.user.fullName, body.user.email,
                                body.user.userType, body.user.phone, body.user.city,
                                body.user.walletBalance, body.user.isApproved == 1,
                                body.nonce != null ? body.nonce : ""
                            );
                        }
                        cb.onSuccess(body);
                    } else {
                        String msg = resp.body() != null ? resp.body().message : "فشل تسجيل الدخول";
                        cb.onError(msg);
                    }
                }
                @Override
                public void onFailure(Call<LoginResponse> call, Throwable t) {
                    cb.onError("خطأ في الاتصال: " + t.getMessage());
                }
            });
    }

    private void fetchCurrentUser(Callback<LoginResponse> cb) {
        api.getCurrentUser().enqueue(new retrofit2.Callback<UserResponse>() {
            @Override
            public void onResponse(Call<UserResponse> call, Response<UserResponse> resp) {
                if (resp.isSuccessful() && resp.body() != null && resp.body().success) {
                    UserResponse.UserData u = resp.body().data;
                    TokenManager.saveUser(ctx, u.id, u.fullName, u.email,
                        u.userType, u.phone, u.city, u.walletBalance,
                        u.isApproved == 1, u.nonce != null ? u.nonce : "");
                    if (u.nonce != null) TokenManager.saveNonce(ctx, u.nonce);

                    // Build fake LoginResponse for the callback
                    LoginResponse lr = new LoginResponse();
                    lr.success = true;
                    lr.nonce = u.nonce;
                    lr.user = new LoginResponse.UserPayload();
                    lr.user.id = u.id;
                    lr.user.fullName = u.fullName;
                    lr.user.email = u.email;
                    lr.user.userType = u.userType;
                    lr.user.phone = u.phone;
                    lr.user.city = u.city;
                    lr.user.walletBalance = u.walletBalance;
                    lr.user.isApproved = u.isApproved;
                    cb.onSuccess(lr);
                } else {
                    cb.onError("تعذر جلب بيانات المستخدم");
                }
            }
            @Override
            public void onFailure(Call<UserResponse> call, Throwable t) {
                cb.onError("خطأ في الاتصال");
            }
        });
    }

    // ── Orders ────────────────────────────────────────────────────
    public void getOrders(String status, Callback<OrdersResponse> cb) {
        String nonce = TokenManager.getNonce(ctx);
        api.getOrders("sirdaba_dist_get_orders", nonce, status)
            .enqueue(wrap(cb));
    }

    // ── Accept Order ──────────────────────────────────────────────
    public void acceptOrder(int orderId, Callback<BaseResponse> cb) {
        String nonce = TokenManager.getNonce(ctx);
        api.acceptOrder("sirdaba_dist_accept_order", orderId, nonce)
            .enqueue(wrap(cb));
    }

    // ── Verify OTP ────────────────────────────────────────────────
    public void verifyDeliveryOtp(int orderId, String otp, Callback<BaseResponse> cb) {
        String nonce = TokenManager.getNonce(ctx);
        api.verifyDeliveryOtp("sirdaba_dist_verify_delivery_otp", orderId, otp, nonce)
            .enqueue(wrap(cb));
    }

    // ── Update Location ───────────────────────────────────────────
    public void updateLocation(int orderId, double lat, double lng, Callback<BaseResponse> cb) {
        String nonce = TokenManager.getNonce(ctx);
        api.updateLocation("sirdaba_update_driver_location", orderId, lat, lng, nonce)
            .enqueue(wrap(cb));
    }

    // ── Register FCM Token ────────────────────────────────────────
    public void registerFcmToken(String fcmToken, Callback<BaseResponse> cb) {
        api.registerDeviceToken(fcmToken, "android", "2.0")
            .enqueue(wrap(cb));
    }

    // ── Notifications ─────────────────────────────────────────────
    public void getNotifications(Callback<NotificationsResponse> cb) {
        String nonce = TokenManager.getNonce(ctx);
        api.getNotifications("sirdaba_get_notifications", nonce)
            .enqueue(wrap(cb));
    }

    // ── Live Updates ──────────────────────────────────────────────
    public void getLiveUpdates(Callback<LiveUpdatesResponse> cb) {
        long lastCheck = TokenManager.getLastCheck(ctx);
        String userType = TokenManager.getUserType(ctx);
        api.getLiveUpdates(lastCheck, userType).enqueue(new retrofit2.Callback<LiveUpdatesResponse>() {
            @Override
            public void onResponse(Call<LiveUpdatesResponse> call, Response<LiveUpdatesResponse> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    TokenManager.saveLastCheck(ctx, System.currentTimeMillis() / 1000L);
                    cb.onSuccess(resp.body());
                } else {
                    cb.onError("فشل تحديث البيانات");
                }
            }
            @Override
            public void onFailure(Call<LiveUpdatesResponse> call, Throwable t) {
                cb.onError(t.getMessage());
            }
        });
    }

    // ── Logout ────────────────────────────────────────────────────
    public void logout(Callback<BaseResponse> cb) {
        String nonce = TokenManager.getNonce(ctx);
        api.distLogout("sirdaba_dist_logout", nonce).enqueue(new retrofit2.Callback<BaseResponse>() {
            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> resp) {
                TokenManager.clearAll(ctx);
                ApiClient.reset();
                cb.onSuccess(new BaseResponse());
            }
            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {
                TokenManager.clearAll(ctx);
                ApiClient.reset();
                cb.onSuccess(new BaseResponse()); // Logout locally even if request fails
            }
        });
    }

    // ── Generic wrapper ───────────────────────────────────────────
    private <T> retrofit2.Callback<T> wrap(Callback<T> cb) {
        return new retrofit2.Callback<T>() {
            @Override
            public void onResponse(Call<T> call, Response<T> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    cb.onSuccess(resp.body());
                } else {
                    cb.onError("خطأ في الطلب: " + resp.code());
                }
            }
            @Override
            public void onFailure(Call<T> call, Throwable t) {
                cb.onError("خطأ في الاتصال: " + t.getMessage());
            }
        };
    }
}
